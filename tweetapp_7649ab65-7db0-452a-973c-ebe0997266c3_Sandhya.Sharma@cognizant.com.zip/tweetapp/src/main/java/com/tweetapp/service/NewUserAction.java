package com.tweetapp.service;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.tweetapp.cognizant.Menu;
import com.tweetapp.dao.UserDao;

public class NewUserAction {
	
	public static UserDao user = new UserDao();
	
	public static boolean isValid(String email)
	{
	String regex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
            "[a-zA-Z0-9_+&*-]+)*@" +
            "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
            "A-Z]{2,7}$";
	Pattern pattern = Pattern.compile(regex);
	if (email == null)
	return false;
	return pattern.matcher(email).matches();
	}
	
	public static void register() {
		Scanner scan = new Scanner(System.in);
		System.out.println("\nRegistering....");
		System.out.println("\nEnter new username : ");
		String username = scan.nextLine().trim();
		System.out.println("Enter new password : ");
		String password = scan.nextLine().trim();
		boolean result = isValid(username);
		
		//	System.out.println("Provided email address "+ email+ " is invalid \n");
			try {
				if (result != true)
				{
				System.out.println("Provided email address "+ username+ " is invalid \n");
				throw new Exception();
				}	
			}catch(Exception e) {
				System.out.println("Enter valid email !!");
				Menu.showMainMenu();
			}
		user.registerUser(username, password);
		
	}
	
	public static String login() {
		Scanner scan = new Scanner(System.in);
		System.out.println("\nLogging In....");
		System.out.println("\nEnter username : ");
		String username = scan.nextLine().trim();
		System.out.println("Enter password : ");
		String password = scan.nextLine().trim();
		if(user.logInUser(username, password)) {
			Menu.isUserLoggedIn=true;
			System.out.println("LoggedIn successfully !!");
			System.out.println("\n===========================================\n");
			return username;
		}
		return null;
	}
	
	public static void forgotPassword() {
		Scanner scan = new Scanner(System.in);
		System.out.println("\nResetting Password..");
		System.out.println("\nEnter username : ");
		String username = scan.nextLine().trim();
		System.out.println("Enter new password : ");
		String password = scan.nextLine().trim();
		boolean resetStatus = user.resetUserPwd(username, password);
		if(resetStatus) {
			System.out.println("Password Reset successfully completed !!");
		}
	}	
	
}
