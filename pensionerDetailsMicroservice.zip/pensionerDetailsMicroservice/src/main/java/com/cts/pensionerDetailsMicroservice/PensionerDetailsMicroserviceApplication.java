package com.cts.pensionerDetailsMicroservice;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;

import com.cts.pensionerDetailsMicroservice.services.pensionerDetailsServiceImpl;

@SpringBootApplication
public class PensionerDetailsMicroserviceApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(PensionerDetailsMicroserviceApplication.class, args);
		
	}

}
