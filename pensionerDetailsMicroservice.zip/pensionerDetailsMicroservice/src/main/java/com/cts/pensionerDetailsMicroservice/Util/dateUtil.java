package com.cts.pensionerDetailsMicroservice.Util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dateUtil {


	public static Date parseDate(String date) throws ParseException {
		return new SimpleDateFormat("dd-MM-yyyy").parse(date);
	}
}
