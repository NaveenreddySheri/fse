package com.cts.pensionerDetailsMicroservice.services;

import java.io.IOException;
import java.text.ParseException;

import com.cts.pensionerDetailsMicroservice.model.pensionerDetails;

public interface pensionerDetailsService {

	public pensionerDetails getPensionerDetailsByAadhaarNo(String aadhaarNo) throws IOException, NumberFormatException;
}
