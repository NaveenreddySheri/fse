package com.cts.pensionerDetailsMicroservice.services;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.pensionerDetailsMicroservice.Util.dateUtil;
import com.cts.pensionerDetailsMicroservice.model.bankDetails;
import com.cts.pensionerDetailsMicroservice.model.pensionerDetails;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class pensionerDetailsServiceImpl implements pensionerDetailsService {

	@Override
	public pensionerDetails getPensionerDetailsByAadhaarNo(String aadhaarNo) throws IOException, NumberFormatException {
		System.out.println(aadhaarNo);
		List pensionerdetails = new ArrayList<pensionerDetails>();
		pensionerDetails findpensionerDetails= new pensionerDetails();
		String line = "";
		BufferedReader br = new BufferedReader(
				new InputStreamReader(this.getClass().getResourceAsStream("/details.csv")));
		while ((line = br.readLine()) != null) // returns a Boolean value
		{
			String[] person = line.split(",");
			pensionerDetails newPensioner;
			try {
				newPensioner = new pensionerDetails(person[0], person[1], dateUtil.parseDate(person[2]), person[3],
						Double.parseDouble(person[4]), Double.parseDouble(person[5]), person[6],
						new bankDetails(person[7], Long.parseLong(person[8]), person[9]));
				pensionerdetails.add(newPensioner);
			} catch (NumberFormatException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (int i = 0; i < pensionerdetails.size(); i++) {
			
			pensionerDetails name = (pensionerDetails) pensionerdetails.get(i);
			System.out.println(name);
			String x = name.getAadharNo();
			System.out.println(aadhaarNo);
			if (aadhaarNo.equals(x)) {
				System.out.println(x);
				findpensionerDetails=name;
			
			break;
			}
			else {
				findpensionerDetails= null;
				//throw exception not found
			}
		
		}
		return findpensionerDetails;
	}
}
