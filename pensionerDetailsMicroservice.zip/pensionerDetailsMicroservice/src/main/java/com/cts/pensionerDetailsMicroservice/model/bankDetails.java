package com.cts.pensionerDetailsMicroservice.model;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class bankDetails {
	
	
	private String bankName;
	private long accountNo;
	private String bankGroup;
	
	
	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public long getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}


	public String getBankGroup() {
		return bankGroup;
	}


	public void setBankGroup(String bankGroup) {
		this.bankGroup = bankGroup;
	}


	public bankDetails(String bankName, long accountNo, String bankGroup) {
		super();
		this.bankName = bankName;
		this.accountNo = accountNo;
		this.bankGroup = bankGroup;
	}
	
	@Override
	public String toString() {
		return "bankDetails [bankName=" + bankName + ", accountNo=" + accountNo + ", bankGroup=" + bankGroup + "]";
	}
}

