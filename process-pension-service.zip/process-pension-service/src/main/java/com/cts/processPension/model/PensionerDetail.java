package com.cts.processPension.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;

public class PensionerDetail {
	
	private String name;
	private String aadharNo;
	@JsonFormat(shape = JsonFormat.Shape.STRING ,pattern = "YYYY-MM-dd" , timezone="IST")
	private Date dateOfBirth;
	private String panNo;
	private double salaryEarned;
	private double allowances;
	private String pensionType;
	private Bank bankInfo;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public double getSalaryEarned() {
		return salaryEarned;
	}
	public void setSalaryEarned(double salaryEarned) {
		this.salaryEarned = salaryEarned;
	}
	public double getAllowances() {
		return allowances;
	}
	public void setAllowances(double allowances) {
		this.allowances = allowances;
	}
	public String getPensionType() {
		return pensionType;
	}
	public void setPensionType(String pensionType) {
		this.pensionType = pensionType;
	}
	public Bank getBankInfo() {
		return bankInfo;
	}
	public void setBankInfo(Bank bankInfo) {
		this.bankInfo = bankInfo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public PensionerDetail() {
		
	}
	public PensionerDetail(String aadharNo, String name, Date dateOfBirth, String panNo, double salaryEarned,
			double allowances, String pensionType, Bank bankInfo) {
		super();
		this.name = name;
		this.aadharNo = aadharNo;
		this.dateOfBirth = dateOfBirth;
		this.panNo = panNo;
		this.salaryEarned = salaryEarned;
		this.allowances = allowances;
		this.pensionType = pensionType;
		this.bankInfo = bankInfo;
	}
	@Override
	public String toString() {
		return "pensionerDetails [name=" + name + ", aadharNo=" + aadharNo + ", dateOfBirth=" + dateOfBirth + ", panNo="
				+ panNo + ", salaryEarned=" + salaryEarned + ", allowances=" + allowances + ", pensionType="
				+ pensionType + ", bankInfo=" + bankInfo + "]";
	}
	
}