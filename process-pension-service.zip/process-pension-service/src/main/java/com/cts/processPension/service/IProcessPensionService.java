package com.cts.processPension.service;

import com.cts.processPension.model.PensionDetail;
import com.cts.processPension.model.PensionerDetail;
import com.cts.processPension.model.PensionerInput;
import com.cts.processPension.model.ProcessPensionInput;
import com.cts.processPension.model.ProcessPensionResponse;

public interface IProcessPensionService {


	public PensionerDetail getPensionerDetails(PensionerInput pensionerInput);

	public PensionDetail processPension( ProcessPensionInput processPensionInput);
}
