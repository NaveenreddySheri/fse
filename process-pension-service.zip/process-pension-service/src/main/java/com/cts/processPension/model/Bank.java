package com.cts.processPension.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Model class for bank details
 * 
 * @author Shubham Nawani
 *
 */
@Getter
@AllArgsConstructor
public class Bank {
	private String bankName;
	private long accountNo;
	private String bankGroup;
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNumber(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankGroup() {
		return bankGroup;
	}
	public void setBankGroup(String bankType) {
		this.bankGroup = bankType;
	}
	@Override
	public String toString() {
		return "Bank [bankName=" + bankName + ", accountNumber=" + accountNo + ", bankType=" + bankGroup + "]";
	}
	
}