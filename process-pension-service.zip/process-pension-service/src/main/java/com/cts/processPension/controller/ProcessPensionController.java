package com.cts.processPension.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cts.processPension.exception.InvalidTokenException;
import com.cts.processPension.feign.AuthorisationClient;
import com.cts.processPension.model.PensionDetail;
import com.cts.processPension.model.PensionerDetail;
import com.cts.processPension.model.PensionerInput;
import com.cts.processPension.model.ProcessPensionInput;
import com.cts.processPension.model.ProcessPensionResponse;
import com.cts.processPension.service.ProcessPensionServiceImpl;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@CrossOrigin
public class ProcessPensionController {

	@Autowired
	ProcessPensionServiceImpl processPensionService;

	@Autowired
	AuthorisationClient authorisationClient;

	@PostMapping("/pensionerInput")
	public ResponseEntity<PensionerDetail> getPensionerDetails(
			@RequestBody @Valid PensionerInput pensionerInput) {
		
		return new ResponseEntity<PensionerDetail>(processPensionService.getPensionerDetails(pensionerInput), HttpStatus.OK);
	}

	@PostMapping("/processPension")
	public ResponseEntity<PensionDetail> processPension( @RequestBody @Valid ProcessPensionInput processPensionInput) {
		return new ResponseEntity<PensionDetail>(processPensionService.processPension(processPensionInput), HttpStatus.OK);
	}
	
	

}