package com.cts.processPension.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.processPension.exception.NotFoundException;
import com.cts.processPension.feign.PensionDisbursementClient;
import com.cts.processPension.feign.PensionerDetailsClient;
import com.cts.processPension.model.PensionAmountDetail;
import com.cts.processPension.model.PensionDetail;
import com.cts.processPension.model.PensionerDetail;
import com.cts.processPension.model.PensionerInput;
import com.cts.processPension.model.ProcessPensionInput;
import com.cts.processPension.model.ProcessPensionResponse;
import com.cts.processPension.repository.PensionDetailsRepository;
import com.cts.processPension.repository.PensionerDetailsRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * Service class for Process Pension
 * 
 * @author Shubham Nawani
 *
 */
@Service
@Slf4j
public class ProcessPensionServiceImpl implements IProcessPensionService {

	@Autowired
	private PensionerDetailsClient pensionerDetailClient;

	@Autowired
	private PensionDisbursementClient pensionDisbursementClient;

	@Autowired
	private PensionDetailsRepository pensionDetailsRepository;

	@Autowired
	private PensionerDetailsRepository pensionerDetailsRepository;

	/**
	 * This method is responsible to get the pension details if input details are
	 * valid
	 * 
	 * @author Shubham Nawani
	 * @param pensionerInput
	 * @return Verified Pension Detail with pension amount
	 */
	@Override
	public PensionerDetail getPensionerDetails(PensionerInput pensionerInput) {
		PensionerDetail pensionerDetail = pensionerDetailClient
				.getPensionerDetailByAadhaar(pensionerInput.getAadhaarNumber());
		System.out.println("****************************************************************************************");
		System.out.println(pensionerDetail);
		return pensionerDetail;
	}

	
	@Override
	public PensionDetail processPension( ProcessPensionInput processPensionInput) {
	
		PensionerDetail pensionerDetail = pensionerDetailClient.getPensionerDetailByAadhaar(processPensionInput.getAadhaarNumber());
		System.out.println("****************************************************************************************");
		System.out.println(pensionerDetail);

		
		double pensionAmount = 0;
		double bankcharges=0;
		
	if(pensionerDetail.getBankInfo().getBankGroup().equalsIgnoreCase("private")) {
			bankcharges=550;
	}
	else {
		bankcharges=500;
	}
		if (pensionerDetail.getPensionType().equalsIgnoreCase("self"))
			pensionAmount = (pensionerDetail.getSalaryEarned()* 0.8 + pensionerDetail.getAllowances());
		else if (pensionerDetail.getPensionType().equalsIgnoreCase("family"))
			pensionAmount = (pensionerDetail.getSalaryEarned() * 0.5 + pensionerDetail.getAllowances());
		return new PensionDetail(pensionerDetail.getName(), pensionerDetail.getDateOfBirth(), pensionerDetail.getPanNo(),
				pensionerDetail.getPensionType(), pensionAmount,bankcharges );
		
	

	}
}